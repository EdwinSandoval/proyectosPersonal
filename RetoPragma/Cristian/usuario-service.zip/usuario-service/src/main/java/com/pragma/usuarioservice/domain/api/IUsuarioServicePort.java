package com.pragma.usuarioservice.domain.api;

import com.pragma.usuarioservice.domain.model.UsuarioModel;

import java.util.List;

public interface IUsuarioServicePort {

    void saveUsers(UsuarioModel usuarioModel);

    List<UsuarioModel> getAllUsers();

}

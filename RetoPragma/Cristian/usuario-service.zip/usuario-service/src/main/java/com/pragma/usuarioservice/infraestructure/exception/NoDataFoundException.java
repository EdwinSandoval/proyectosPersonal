package com.pragma.usuarioservice.infraestructure.exception;

public class NoDataFoundException extends RuntimeException{
    public NoDataFoundException() {
        super();
    }
}

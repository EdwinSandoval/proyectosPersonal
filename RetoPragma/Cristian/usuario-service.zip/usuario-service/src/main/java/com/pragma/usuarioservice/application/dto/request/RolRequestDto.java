package com.pragma.usuarioservice.application.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RolRequestDto {

    private String nombre;

    private String descripcion;
}

package com.pragma.usuarioservice.application.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RolResponseDto {

    private Long id;

    private String nombre;

    private String descripcion;

}

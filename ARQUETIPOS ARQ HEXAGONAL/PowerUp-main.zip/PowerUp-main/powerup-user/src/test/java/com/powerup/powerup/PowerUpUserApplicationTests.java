package com.powerup.powerup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PowerUpUserApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.powerup.user.infraestructure.auth;

public class UserAuthDto {
}

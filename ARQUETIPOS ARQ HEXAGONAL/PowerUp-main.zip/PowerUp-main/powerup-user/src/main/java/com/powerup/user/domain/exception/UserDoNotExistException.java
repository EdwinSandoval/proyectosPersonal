package com.powerup.user.domain.exception;

public class UserDoNotExistException extends RuntimeException{

    public UserDoNotExistException(){super();}

}

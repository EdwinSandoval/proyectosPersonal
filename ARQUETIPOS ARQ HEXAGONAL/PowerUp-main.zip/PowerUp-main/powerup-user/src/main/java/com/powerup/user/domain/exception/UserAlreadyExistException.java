package com.powerup.user.domain.exception;

public class UserAlreadyExistException extends RuntimeException{
    public UserAlreadyExistException() {
            super();
    }
}

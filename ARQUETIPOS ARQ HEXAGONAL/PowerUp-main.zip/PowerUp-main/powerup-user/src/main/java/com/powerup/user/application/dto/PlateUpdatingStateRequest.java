package com.powerup.user.application.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlateUpdatingStateRequest {


    private Long id;


    private boolean activate;
}

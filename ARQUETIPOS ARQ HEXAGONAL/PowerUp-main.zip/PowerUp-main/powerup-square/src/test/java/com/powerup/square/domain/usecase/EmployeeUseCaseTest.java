package com.powerup.square.domain.usecase;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(SpringExtension.class)
class EmployeeUseCaseTest {

    @Test
    void saveEmployee() {
    }

    @Test
    void getAllEmployee() {
    }

    @Test
    void getEmployee() {
    }
}
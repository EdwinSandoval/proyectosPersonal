package com.powerup.square.application.handler.impl;

import com.powerup.square.application.dto.EmployeeRequest;
import com.powerup.square.application.dto.RestaurantRequest;
import com.powerup.square.domain.model.Employee;


public class SaveEmployeeHanlerDataTest {


    public static Employee obtainEmployee(){





        return null;

    }


    public static EmployeeRequest obtainEmployeeRequest(){
        EmployeeRequest employeeRequestRequest = new EmployeeRequest();


        return null;
    }
}

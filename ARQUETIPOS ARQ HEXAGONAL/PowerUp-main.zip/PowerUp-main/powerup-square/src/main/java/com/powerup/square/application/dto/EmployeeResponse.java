package com.powerup.square.application.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeResponse {

    private Long idUser;
    private Long idRestaurant;
    private String field;
}

package com.powerup.square.domain.exception;


// exception order
public class PendingExistsException extends RuntimeException{

    public PendingExistsException(){
        super();
    }
}

package com.powerup.square.application.dto;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PlateUpdatingStateRequest {

    private Long id;


    private boolean activate;



}

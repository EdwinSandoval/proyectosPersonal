package com.powerup.square.domain.exception;

public class OrderIsNotPendingException extends RuntimeException {

    public OrderIsNotPendingException(){
        super();
    }

}

package com.powerup.square.application.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RestaurantListResponse {

    private String name;
    private String urlLogo;
}

package com.powerup.square.application.dto.pin;

public class UserPin {
}

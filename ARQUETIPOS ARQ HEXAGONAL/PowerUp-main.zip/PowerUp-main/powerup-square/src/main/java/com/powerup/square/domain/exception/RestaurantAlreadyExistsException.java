package com.powerup.square.domain.exception;

public class RestaurantAlreadyExistsException extends RuntimeException{

    public RestaurantAlreadyExistsException(){
        super();
    }

}

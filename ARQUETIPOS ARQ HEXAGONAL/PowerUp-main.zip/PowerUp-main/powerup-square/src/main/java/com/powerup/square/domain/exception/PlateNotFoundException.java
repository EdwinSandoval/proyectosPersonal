package com.powerup.square.domain.exception;

public class PlateNotFoundException extends RuntimeException{

    public PlateNotFoundException(){
        super();
    }

}

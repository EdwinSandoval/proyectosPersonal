package com.powerup.square.application.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderState {
    // private Long idEmployee;
    private String state;

    private Long idEmployee;
}

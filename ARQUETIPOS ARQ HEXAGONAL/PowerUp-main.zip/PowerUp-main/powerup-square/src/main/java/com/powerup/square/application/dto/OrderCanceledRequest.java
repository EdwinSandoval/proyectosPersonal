package com.powerup.square.application.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderCanceledRequest {

    private Long idClient;


}

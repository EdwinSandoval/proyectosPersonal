package com.powerup.square.domain.exception;

public class PlateIsNotRestaurantException extends RuntimeException{

    public PlateIsNotRestaurantException(){
        super();
    }

}

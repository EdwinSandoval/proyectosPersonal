package com.powerup.square;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PowerUpSquareApplication {

	public static void main(String[] args) {
		SpringApplication.run(PowerUpSquareApplication.class, args);
	}

}

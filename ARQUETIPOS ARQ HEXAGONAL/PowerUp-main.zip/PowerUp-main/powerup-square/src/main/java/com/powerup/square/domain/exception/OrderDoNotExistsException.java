package com.powerup.square.domain.exception;

public class OrderDoNotExistsException extends  RuntimeException{

    public OrderDoNotExistsException(){
        super();
    }
}

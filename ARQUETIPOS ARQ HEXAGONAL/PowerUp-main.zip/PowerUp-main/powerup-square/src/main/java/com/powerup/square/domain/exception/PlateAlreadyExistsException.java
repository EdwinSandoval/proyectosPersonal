package com.powerup.square.domain.exception;

public class PlateAlreadyExistsException extends RuntimeException{

    public PlateAlreadyExistsException(){
        super();
    }

}

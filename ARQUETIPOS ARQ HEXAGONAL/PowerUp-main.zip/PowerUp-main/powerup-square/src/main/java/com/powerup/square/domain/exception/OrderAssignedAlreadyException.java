package com.powerup.square.domain.exception;

public class OrderAssignedAlreadyException extends RuntimeException{

    public OrderAssignedAlreadyException(){
        super();
    }
}

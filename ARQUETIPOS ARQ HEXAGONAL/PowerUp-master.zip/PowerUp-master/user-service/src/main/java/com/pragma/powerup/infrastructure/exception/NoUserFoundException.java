package com.pragma.powerup.infrastructure.exception;

public class NoUserFoundException extends RuntimeException{

    public NoUserFoundException(){
        super();
    }
}

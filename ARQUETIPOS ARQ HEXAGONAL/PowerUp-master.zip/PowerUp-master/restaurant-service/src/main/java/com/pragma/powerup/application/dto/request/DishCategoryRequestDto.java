package com.pragma.powerup.application.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DishCategoryRequestDto {
    private String name;
    private String description;
}

package com.pragma.powerup.infrastructure.exception;

public class NoRestaurantFoundException extends RuntimeException{
    public NoRestaurantFoundException() {
        super();
    }
}

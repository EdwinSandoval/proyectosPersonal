package com.pragma.powerup.infrastructure.exception;

public class NoCategoryFoundException extends RuntimeException{
    public NoCategoryFoundException() {
        super();
    }
}

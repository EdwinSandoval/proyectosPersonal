package com.pragma.powerup.application.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RestaurantEmpRequestDto {
    private Long user;
    private Long restaurant;
}

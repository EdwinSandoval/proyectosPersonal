package com.pragma.powerup.application.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DishCategoryResponseDto {
    private Long id;
    private String name;
    private String description;
}

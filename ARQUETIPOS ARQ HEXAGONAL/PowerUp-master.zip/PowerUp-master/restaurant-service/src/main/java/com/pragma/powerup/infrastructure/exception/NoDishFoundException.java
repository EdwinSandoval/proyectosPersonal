package com.pragma.powerup.infrastructure.exception;

public class NoDishFoundException extends RuntimeException{
    public NoDishFoundException() {
        super();
    }
}

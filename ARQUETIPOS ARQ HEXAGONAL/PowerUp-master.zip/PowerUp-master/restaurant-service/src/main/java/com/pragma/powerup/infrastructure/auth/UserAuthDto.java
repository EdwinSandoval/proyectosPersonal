package com.pragma.powerup.infrastructure.auth;

public class UserAuthDto {
}

package com.pragma.powerup.infrastructure.exception;

public class NonAdminUserException extends RuntimeException{
    public NonAdminUserException() {
        super();
    }
}

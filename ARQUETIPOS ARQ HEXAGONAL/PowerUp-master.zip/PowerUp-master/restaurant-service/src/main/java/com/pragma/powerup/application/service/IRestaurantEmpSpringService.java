package com.pragma.powerup.application.service;

import com.pragma.powerup.application.dto.request.EmployeeRequestDto;
import com.pragma.powerup.application.dto.request.RestaurantEmpRequestDto;

public interface IRestaurantEmpSpringService {
    void saveRestaurantEmp(RestaurantEmpRequestDto restaurantEmpRequestDto);
}
